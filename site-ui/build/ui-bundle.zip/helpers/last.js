'use strict'

module.exports = (c) => c[c.length - 1]
